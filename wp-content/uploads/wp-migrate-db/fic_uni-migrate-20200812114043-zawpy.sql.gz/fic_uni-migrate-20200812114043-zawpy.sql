# WordPress MySQL database migration
#
# Generated: Wednesday 12. August 2020 11:40 UTC
# Hostname: localhost
# Database: `fic_uni`
# URL: //tac.epizy.com
# Path: S:\\xampp\\htdocs\\wordpress\\fic_uni
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, campus, event, like, note, page, post, professor, program
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-07-15 06:22:42', '2020-07-15 06:22:42', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=661 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://tac.epizy.com', 'yes'),
(2, 'home', 'http://tac.epizy.com', 'yes'),
(3, 'blogname', 'Fictional University', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'abdulbasit4@hotmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:212:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:11:"campuses/?$";s:26:"index.php?post_type=campus";s:41:"campuses/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=campus&feed=$matches[1]";s:36:"campuses/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=campus&feed=$matches[1]";s:28:"campuses/page/([0-9]{1,})/?$";s:44:"index.php?post_type=campus&paged=$matches[1]";s:9:"events/?$";s:25:"index.php?post_type=event";s:39:"events/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:34:"events/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:26:"events/page/([0-9]{1,})/?$";s:43:"index.php?post_type=event&paged=$matches[1]";s:11:"programs/?$";s:27:"index.php?post_type=program";s:41:"programs/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=program&feed=$matches[1]";s:36:"programs/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=program&feed=$matches[1]";s:28:"programs/page/([0-9]{1,})/?$";s:45:"index.php?post_type=program&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:36:"campuses/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"campuses/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"campuses/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campuses/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campuses/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"campuses/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"campuses/([^/]+)/embed/?$";s:39:"index.php?campus=$matches[1]&embed=true";s:29:"campuses/([^/]+)/trackback/?$";s:33:"index.php?campus=$matches[1]&tb=1";s:49:"campuses/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?campus=$matches[1]&feed=$matches[2]";s:44:"campuses/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?campus=$matches[1]&feed=$matches[2]";s:37:"campuses/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?campus=$matches[1]&paged=$matches[2]";s:44:"campuses/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?campus=$matches[1]&cpage=$matches[2]";s:33:"campuses/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?campus=$matches[1]&page=$matches[2]";s:25:"campuses/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"campuses/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"campuses/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campuses/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campuses/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"campuses/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"events/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"events/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"events/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"events/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"events/([^/]+)/embed/?$";s:38:"index.php?event=$matches[1]&embed=true";s:27:"events/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:47:"events/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:42:"events/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:35:"events/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:42:"events/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:31:"events/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:23:"events/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"events/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"events/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"events/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"like/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"like/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"like/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"like/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"like/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"like/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"like/([^/]+)/embed/?$";s:37:"index.php?like=$matches[1]&embed=true";s:25:"like/([^/]+)/trackback/?$";s:31:"index.php?like=$matches[1]&tb=1";s:33:"like/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?like=$matches[1]&paged=$matches[2]";s:40:"like/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?like=$matches[1]&cpage=$matches[2]";s:29:"like/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?like=$matches[1]&page=$matches[2]";s:21:"like/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"like/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"like/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"like/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"like/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"like/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:"note/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"note/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"note/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"note/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"note/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"note/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"note/([^/]+)/embed/?$";s:37:"index.php?note=$matches[1]&embed=true";s:25:"note/([^/]+)/trackback/?$";s:31:"index.php?note=$matches[1]&tb=1";s:33:"note/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?note=$matches[1]&paged=$matches[2]";s:40:"note/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?note=$matches[1]&cpage=$matches[2]";s:29:"note/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?note=$matches[1]&page=$matches[2]";s:21:"note/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"note/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"note/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"note/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"note/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"note/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"programs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"programs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"programs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"programs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"programs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"programs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"programs/([^/]+)/embed/?$";s:40:"index.php?program=$matches[1]&embed=true";s:29:"programs/([^/]+)/trackback/?$";s:34:"index.php?program=$matches[1]&tb=1";s:49:"programs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?program=$matches[1]&feed=$matches[2]";s:44:"programs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?program=$matches[1]&feed=$matches[2]";s:37:"programs/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?program=$matches[1]&paged=$matches[2]";s:44:"programs/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?program=$matches[1]&cpage=$matches[2]";s:33:"programs/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?program=$matches[1]&page=$matches[2]";s:25:"programs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"programs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"programs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"programs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"programs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"programs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:37:"professor/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"professor/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"professor/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"professor/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"professor/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"professor/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"professor/([^/]+)/embed/?$";s:42:"index.php?professor=$matches[1]&embed=true";s:30:"professor/([^/]+)/trackback/?$";s:36:"index.php?professor=$matches[1]&tb=1";s:38:"professor/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?professor=$matches[1]&paged=$matches[2]";s:45:"professor/([^/]+)/comment-page-([0-9]{1,})/?$";s:49:"index.php?professor=$matches[1]&cpage=$matches[2]";s:34:"professor/([^/]+)(?:/([0-9]+))?/?$";s:48:"index.php?professor=$matches[1]&page=$matches[2]";s:26:"professor/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"professor/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"professor/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"professor/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"professor/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"professor/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=22&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:39:"manual-image-crop/manual-image-crop.php";i:2;s:19:"members/members.php";i:3;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'fictional-university-theme', 'yes'),
(41, 'stylesheet', 'fictional-university-theme', 'yes'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '48748', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '20', 'yes'),
(84, 'page_on_front', '22', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'admin_email_lifespan', '1610346157', 'yes'),
(94, 'initial_db_version', '47018', 'yes'),
(95, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:96:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:16:"restrict_content";b:1;s:10:"list_roles";b:1;s:12:"create_roles";b:1;s:12:"delete_roles";b:1;s:10:"edit_roles";b:1;s:13:"delete_events";b:1;s:20:"delete_others_events";b:1;s:21:"delete_private_events";b:1;s:23:"delete_published_events";b:1;s:11:"edit_events";b:1;s:18:"edit_others_events";b:1;s:19:"edit_private_events";b:1;s:21:"edit_published_events";b:1;s:14:"publish_events";b:1;s:19:"read_private_events";b:1;s:14:"delete_campuss";b:1;s:21:"delete_others_campuss";b:1;s:22:"delete_private_campuss";b:1;s:24:"delete_published_campuss";b:1;s:12:"edit_campuss";b:1;s:19:"edit_others_campuss";b:1;s:20:"edit_private_campuss";b:1;s:22:"edit_published_campuss";b:1;s:15:"publish_campuss";b:1;s:20:"read_private_campuss";b:1;s:10:"edit_notes";b:1;s:17:"edit_others_notes";b:1;s:12:"delete_notes";b:1;s:13:"publish_notes";b:1;s:18:"read_private_notes";b:1;s:20:"delete_private_notes";b:1;s:22:"delete_published_notes";b:1;s:19:"delete_others_notes";b:1;s:18:"edit_private_notes";b:1;s:20:"edit_published_notes";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:5:{s:4:"read";b:1;s:7:"level_0";b:1;s:12:"delete_notes";b:1;s:10:"edit_notes";b:1;s:13:"publish_notes";b:1;}}s:13:"event_planner";a:2:{s:4:"name";s:13:"Event Planner";s:12:"capabilities";a:11:{s:4:"read";b:1;s:11:"edit_events";b:1;s:18:"edit_others_events";b:1;s:13:"delete_events";b:1;s:14:"publish_events";b:1;s:19:"read_private_events";b:1;s:21:"delete_private_events";b:1;s:23:"delete_published_events";b:1;s:20:"delete_others_events";b:1;s:19:"edit_private_events";b:1;s:21:"edit_published_events";b:1;}}s:14:"campus_manager";a:2:{s:4:"name";s:14:"Campus Manager";s:12:"capabilities";a:11:{s:4:"read";b:1;s:12:"edit_campuss";b:1;s:19:"edit_others_campuss";b:1;s:14:"delete_campuss";b:1;s:15:"publish_campuss";b:1;s:20:"read_private_campuss";b:1;s:22:"delete_private_campuss";b:1;s:24:"delete_published_campuss";b:1;s:21:"delete_others_campuss";b:1;s:20:"edit_private_campuss";b:1;s:22:"edit_published_campuss";b:1;}}}', 'yes'),
(96, 'fresh_site', '0', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(103, 'cron', 'a:7:{i:1597234965;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1597256565;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1597299764;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1597299765;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1597299776;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1597299781;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(104, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'recovery_keys', 'a:0:{}', 'yes'),
(116, 'theme_mods_twentytwenty', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1594794776;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";}s:9:"sidebar-2";a:3:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";i:2;s:6:"meta-2";}}}}', 'yes'),
(143, 'recently_activated', 'a:0:{}', 'yes'),
(144, 'current_theme', 'Fictional University', 'yes'),
(145, 'theme_mods_fictional-university-theme', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(146, 'theme_switched', '', 'yes'),
(165, 'category_children', 'a:0:{}', 'yes'),
(236, 'acf_version', '5.8.13', 'yes'),
(240, 'recovery_mode_email_last_sent', '1596909178', 'yes'),
(294, 'mic_make2x', 'true', 'yes'),
(503, 'members_addons_migrated', '1', 'yes'),
(504, 'widget_members-widget-login', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(505, 'widget_members-widget-users', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(509, 'WPLANG', '', 'yes'),
(510, 'new_admin_email', 'abdulbasit4@hotmail.com', 'yes'),
(622, 'disallowed_keys', '', 'no'),
(623, 'comment_previously_approved', '1', 'yes'),
(624, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(625, 'finished_updating_comment_type', '1', 'yes'),
(626, 'db_upgraded', '', 'yes'),
(629, 'can_compress_scripts', '1', 'no'),
(641, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1597232443;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=483 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_wp_trash_meta_status', 'publish'),
(4, 1, '_wp_trash_meta_time', '1594794223'),
(5, 1, '_wp_desired_post_slug', 'hello-world'),
(6, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(7, 3, '_wp_trash_meta_status', 'draft'),
(8, 3, '_wp_trash_meta_time', '1594794231'),
(9, 3, '_wp_desired_post_slug', 'privacy-policy'),
(10, 2, '_wp_trash_meta_status', 'publish'),
(11, 2, '_wp_trash_meta_time', '1594794231'),
(12, 2, '_wp_desired_post_slug', 'sample-page'),
(13, 8, '_edit_lock', '1596108379:1'),
(15, 10, '_edit_lock', '1596108373:1'),
(17, 12, '_edit_lock', '1596108365:1'),
(19, 14, '_edit_lock', '1596290108:1'),
(20, 16, '_edit_lock', '1594817219:1'),
(21, 18, '_edit_lock', '1594817275:1'),
(22, 20, '_edit_lock', '1594817631:1'),
(23, 22, '_edit_lock', '1594817307:1'),
(24, 24, '_edit_lock', '1594817338:1'),
(25, 26, '_edit_lock', '1594817366:1'),
(26, 28, '_edit_lock', '1594817389:1'),
(27, 30, '_edit_last', '1'),
(28, 30, '_edit_lock', '1594905321:1'),
(29, 31, '_edit_last', '1'),
(30, 31, '_edit_lock', '1596044971:1'),
(31, 32, '_edit_last', '1'),
(32, 32, '_edit_lock', '1596045129:1'),
(34, 34, '_edit_last', '1'),
(35, 34, '_edit_lock', '1594902778:1'),
(36, 32, 'event_date', '20200902'),
(37, 32, '_event_date', 'field_5f102296d7d7f'),
(38, 31, 'event_date', '20200722'),
(39, 31, '_event_date', 'field_5f102296d7d7f'),
(40, 30, 'event_date', '20200715'),
(41, 30, '_event_date', 'field_5f102296d7d7f'),
(42, 36, '_edit_last', '1'),
(43, 36, '_edit_lock', '1594906511:1'),
(44, 36, 'event_date', '20201201'),
(45, 36, '_event_date', 'field_5f102296d7d7f'),
(46, 37, '_edit_last', '1'),
(47, 37, '_edit_lock', '1594906601:1'),
(48, 37, 'event_date', '20200720'),
(49, 37, '_event_date', 'field_5f102296d7d7f'),
(50, 38, '_edit_lock', '1594998661:1'),
(51, 40, '_edit_last', '1'),
(52, 40, '_edit_lock', '1596105348:1'),
(53, 40, 'event_date', '20190101'),
(54, 40, '_event_date', 'field_5f102296d7d7f'),
(55, 41, '_edit_last', '1'),
(56, 41, '_edit_lock', '1596107935:1'),
(57, 42, '_edit_last', '1'),
(58, 42, '_edit_lock', '1596107687:1'),
(59, 43, '_edit_last', '1'),
(60, 43, '_edit_lock', '1596807617:1'),
(61, 44, '_edit_last', '1'),
(62, 44, '_edit_lock', '1595073855:1'),
(63, 31, 'related_programs', 'a:2:{i:0;s:2:"42";i:1;s:2:"41";}'),
(64, 31, '_related_programs', 'field_5f11dfb711d11'),
(65, 46, '_edit_last', '1'),
(66, 46, '_edit_lock', '1596037535:1'),
(67, 47, '_edit_last', '1'),
(68, 47, '_edit_lock', '1596891982:1'),
(69, 47, 'related_programs', 'a:2:{i:0;s:2:"42";i:1;s:2:"71";}'),
(70, 47, '_related_programs', 'field_5f11dfb711d11'),
(73, 49, '_wp_attached_file', '2020/07/Dr.Barksalot-scaled.jpg'),
(74, 49, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1442;s:4:"file";s:31:"2020/07/Dr.Barksalot-scaled.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:24:"Dr.Barksalot-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Dr.Barksalot-1024x577.jpg";s:5:"width";i:1024;s:6:"height";i:577;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:24:"Dr.Barksalot-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Dr.Barksalot-768x433.jpg";s:5:"width";i:768;s:6:"height";i:433;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:25:"Dr.Barksalot-1536x865.jpg";s:5:"width";i:1536;s:6:"height";i:865;s:9:"mime-type";s:10:"image/jpeg";}s:9:"2048x2048";a:4:{s:4:"file";s:26:"Dr.Barksalot-2048x1154.jpg";s:5:"width";i:2048;s:6:"height";i:1154;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorlandscape";a:4:{s:4:"file";s:24:"Dr.Barksalot-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorportrait";a:4:{s:4:"file";s:24:"Dr.Barksalot-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"Dr.Barksalot.jpg";s:15:"micSelectedArea";a:1:{s:17:"professorportrait";a:5:{s:1:"x";s:3:"125";s:1:"y";s:1:"0";s:1:"w";s:18:"208.24615384615424";s:1:"h";s:18:"281.99999999999994";s:5:"scale";s:4:"5.12";}}}'),
(75, 49, '_wp_attachment_image_alt', 'Dr.Barksalot'),
(76, 47, '_thumbnail_id', '49'),
(77, 50, '_wp_attached_file', '2020/07/Dr.Meowsalot-scaled.jpg'),
(78, 50, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:31:"2020/07/Dr.Meowsalot-scaled.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:24:"Dr.Meowsalot-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Dr.Meowsalot-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:24:"Dr.Meowsalot-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Dr.Meowsalot-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:26:"Dr.Meowsalot-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:9:"2048x2048";a:4:{s:4:"file";s:26:"Dr.Meowsalot-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorlandscape";a:4:{s:4:"file";s:24:"Dr.Meowsalot-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorportrait";a:4:{s:4:"file";s:24:"Dr.Meowsalot-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.4";s:6:"credit";s:0:"";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1508858725";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"50";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:4:"0.01";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"Dr.Meowsalot.jpg";s:15:"micSelectedArea";a:1:{s:17:"professorportrait";a:5:{s:1:"x";s:1:"0";s:1:"y";s:1:"0";s:1:"w";s:17:"245.9076923076928";s:1:"h";s:3:"333";s:5:"scale";s:4:"5.12";}}}'),
(79, 50, '_wp_attachment_image_alt', 'Dr.Meowsalot'),
(80, 46, '_thumbnail_id', '50'),
(81, 46, 'related_programs', 'a:1:{i:0;s:2:"42";}'),
(82, 46, '_related_programs', 'field_5f11dfb711d11'),
(83, 51, '_edit_last', '1'),
(84, 51, '_edit_lock', '1596807631:1'),
(85, 52, '_wp_attached_file', '2020/07/Dr.Froggerson-scaled.jpg'),
(86, 52, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:32:"2020/07/Dr.Froggerson-scaled.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:25:"Dr.Froggerson-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"Dr.Froggerson-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:25:"Dr.Froggerson-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"Dr.Froggerson-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:27:"Dr.Froggerson-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:9:"2048x2048";a:4:{s:4:"file";s:27:"Dr.Froggerson-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorlandscape";a:4:{s:4:"file";s:25:"Dr.Froggerson-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorportrait";a:4:{s:4:"file";s:25:"Dr.Froggerson-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.6";s:6:"credit";s:14:"Edoardo Deluca";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1583339788";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"50";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"Dr.Froggerson.jpg";s:15:"micSelectedArea";a:1:{s:17:"professorportrait";a:5:{s:1:"x";s:2:"37";s:1:"y";s:1:"0";s:1:"w";s:17:"245.9076923076928";s:1:"h";s:3:"333";s:5:"scale";s:4:"5.12";}}}'),
(87, 52, '_wp_attachment_image_alt', 'Dr.Froggerson'),
(88, 51, '_thumbnail_id', '52'),
(89, 51, 'related_programs', 'a:1:{i:0;s:2:"41";}'),
(90, 51, '_related_programs', 'field_5f11dfb711d11'),
(91, 53, '_edit_last', '1'),
(92, 53, '_edit_lock', '1595095425:1'),
(93, 56, '_wp_attached_file', '2020/07/sharon-mccutcheon-62vi3TG5EDg-unsplash-scaled.jpg'),
(94, 56, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:57:"2020/07/sharon-mccutcheon-62vi3TG5EDg-unsplash-scaled.jpg";s:5:"sizes";a:9:{s:6:"medium";a:4:{s:4:"file";s:50:"sharon-mccutcheon-62vi3TG5EDg-unsplash-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:51:"sharon-mccutcheon-62vi3TG5EDg-unsplash-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:50:"sharon-mccutcheon-62vi3TG5EDg-unsplash-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:50:"sharon-mccutcheon-62vi3TG5EDg-unsplash-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:52:"sharon-mccutcheon-62vi3TG5EDg-unsplash-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:9:"2048x2048";a:4:{s:4:"file";s:52:"sharon-mccutcheon-62vi3TG5EDg-unsplash-2048x1365.jpg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorlandscape";a:4:{s:4:"file";s:50:"sharon-mccutcheon-62vi3TG5EDg-unsplash-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorportrait";a:4:{s:4:"file";s:50:"sharon-mccutcheon-62vi3TG5EDg-unsplash-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}s:10:"pagebanner";a:4:{s:4:"file";s:51:"sharon-mccutcheon-62vi3TG5EDg-unsplash-1500x350.jpg";s:5:"width";i:1500;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:42:"sharon-mccutcheon-62vi3TG5EDg-unsplash.jpg";s:15:"micSelectedArea";a:1:{s:10:"pagebanner";a:5:{s:1:"x";s:1:"0";s:1:"y";s:1:"0";s:1:"w";s:3:"500";s:1:"h";s:18:"116.66666666666629";s:5:"scale";s:4:"5.12";}}}'),
(95, 56, '_wp_attachment_image_alt', 'sharon mccutcheon'),
(96, 47, 'page_banner_subtitle', 'The leading voice on barking and biology.'),
(97, 47, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(98, 47, 'page_banner_background_image', '56'),
(99, 47, '_page_banner_background_image', 'field_5f13390ee1767'),
(100, 57, '_wp_attached_file', '2020/07/architecture.jpg'),
(101, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1279;s:4:"file";s:24:"2020/07/architecture.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:24:"architecture-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"architecture-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:24:"architecture-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"architecture-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:26:"architecture-1536x1023.jpg";s:5:"width";i:1536;s:6:"height";i:1023;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorlandscape";a:4:{s:4:"file";s:24:"architecture-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorportrait";a:4:{s:4:"file";s:24:"architecture-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}s:10:"pagebanner";a:4:{s:4:"file";s:25:"architecture-1500x350.jpg";s:5:"width";i:1500;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(102, 57, '_wp_attachment_image_alt', 'architecture'),
(103, 14, '_edit_last', '1'),
(104, 14, 'page_banner_subtitle', 'We are a great school that has been around for a long time.'),
(105, 14, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(106, 14, 'page_banner_background_image', '57') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(107, 14, '_page_banner_background_image', 'field_5f13390ee1767'),
(108, 59, 'page_banner_subtitle', 'We are a great school that has been around for a long time.'),
(109, 59, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(110, 59, 'page_banner_background_image', '57'),
(111, 59, '_page_banner_background_image', 'field_5f13390ee1767'),
(112, 60, '_wp_attached_file', '2020/07/valentines.jpg'),
(113, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:22:"2020/07/valentines.jpg";s:5:"sizes";a:8:{s:6:"medium";a:4:{s:4:"file";s:22:"valentines-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"valentines-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:22:"valentines-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"valentines-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:9:"1536x1536";a:4:{s:4:"file";s:24:"valentines-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:18:"professorlandscape";a:4:{s:4:"file";s:22:"valentines-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:17:"professorportrait";a:4:{s:4:"file";s:22:"valentines-480x650.jpg";s:5:"width";i:480;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";}s:10:"pagebanner";a:4:{s:4:"file";s:23:"valentines-1500x350.jpg";s:5:"width";i:1500;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"5.6";s:6:"credit";s:0:"";s:6:"camera";s:9:"ILCE-7RM2";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"85";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:5:"0.001";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(114, 60, '_wp_attachment_image_alt', 'valentines'),
(115, 32, 'page_banner_subtitle', 'The greatest day of the year.'),
(116, 32, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(117, 32, 'page_banner_background_image', '60'),
(118, 32, '_page_banner_background_image', 'field_5f13390ee1767'),
(119, 32, 'related_programs', 'a:1:{i:0;s:2:"43";}'),
(120, 32, '_related_programs', 'field_5f11dfb711d11'),
(121, 61, '_edit_last', '1'),
(122, 61, '_edit_lock', '1595251628:1'),
(123, 61, 'page_banner_subtitle', 'A beautiful campus in the heart of downtown.'),
(124, 61, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(125, 61, 'page_banner_background_image', ''),
(126, 61, '_page_banner_background_image', 'field_5f13390ee1767'),
(127, 62, '_edit_last', '1'),
(128, 62, '_edit_lock', '1596213320:1'),
(129, 62, 'page_banner_subtitle', 'The beautiful campus on the Downtown East.'),
(130, 62, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(131, 62, 'page_banner_background_image', ''),
(132, 62, '_page_banner_background_image', 'field_5f13390ee1767'),
(133, 63, '_edit_last', '1'),
(134, 63, '_edit_lock', '1595251717:1'),
(135, 61, 'map_location', ''),
(136, 61, '_map_location', 'field_5f1583d4b8d5b'),
(137, 62, 'map_location', ''),
(138, 62, '_map_location', 'field_5f1583d4b8d5b'),
(139, 66, '_edit_last', '1'),
(140, 66, '_edit_lock', '1596105378:1'),
(141, 41, 'page_banner_subtitle', ''),
(142, 41, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(143, 41, 'page_banner_background_image', ''),
(144, 41, '_page_banner_background_image', 'field_5f13390ee1767'),
(145, 41, 'related_campus', 'a:1:{i:0;s:2:"61";}'),
(146, 41, '_related_campus', 'field_5f1dc9b9d7c5b'),
(147, 68, '_edit_lock', '1596290096:1'),
(149, 68, '_edit_last', '1'),
(150, 68, '_encloseme', '1'),
(151, 68, 'page_banner_subtitle', ''),
(152, 68, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(153, 68, 'page_banner_background_image', ''),
(154, 68, '_page_banner_background_image', 'field_5f13390ee1767'),
(155, 69, 'page_banner_subtitle', ''),
(156, 69, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(157, 69, 'page_banner_background_image', ''),
(158, 69, '_page_banner_background_image', 'field_5f13390ee1767'),
(159, 42, 'page_banner_subtitle', ''),
(160, 42, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(161, 42, 'page_banner_background_image', ''),
(162, 42, '_page_banner_background_image', 'field_5f13390ee1767'),
(163, 42, 'related_campus', ''),
(164, 42, '_related_campus', 'field_5f1dc9b9d7c5b'),
(165, 46, 'page_banner_subtitle', ''),
(166, 46, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(167, 46, 'page_banner_background_image', ''),
(168, 46, '_page_banner_background_image', 'field_5f13390ee1767'),
(169, 71, '_edit_last', '1'),
(170, 71, '_edit_lock', '1596041367:1'),
(171, 71, 'page_banner_subtitle', ''),
(172, 71, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(173, 71, 'page_banner_background_image', ''),
(174, 71, '_page_banner_background_image', 'field_5f13390ee1767'),
(175, 71, 'related_campus', ''),
(176, 71, '_related_campus', 'field_5f1dc9b9d7c5b'),
(177, 71, '_wp_trash_meta_status', 'publish'),
(178, 71, '_wp_trash_meta_time', '1596042144'),
(179, 71, '_wp_desired_post_slug', 'mathbiology'),
(180, 72, '_edit_last', '1'),
(181, 72, '_edit_lock', '1596807655:1'),
(182, 42, 'main_body_content', '<strong>biology program is working closing wtih math program.\r\nLorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(183, 42, '_main_body_content', 'field_5f21ae14a980c'),
(184, 43, 'main_body_content', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(185, 43, '_main_body_content', 'field_5f21ae14a980c'),
(186, 43, 'page_banner_subtitle', ''),
(187, 43, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(188, 43, 'page_banner_background_image', ''),
(189, 43, '_page_banner_background_image', 'field_5f13390ee1767'),
(190, 43, 'related_campus', ''),
(191, 43, '_related_campus', 'field_5f1dc9b9d7c5b'),
(192, 41, 'main_body_content', '<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(193, 41, '_main_body_content', 'field_5f21ae14a980c'),
(194, 74, '_edit_lock', '1596121935:1'),
(195, 74, '_edit_last', '1'),
(196, 74, 'page_banner_subtitle', ''),
(197, 74, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(198, 74, 'page_banner_background_image', ''),
(199, 74, '_page_banner_background_image', 'field_5f13390ee1767'),
(200, 75, 'page_banner_subtitle', ''),
(201, 75, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(202, 75, 'page_banner_background_image', ''),
(203, 75, '_page_banner_background_image', 'field_5f13390ee1767'),
(204, 77, '_edit_lock', '1596211976:2'),
(205, 77, '_edit_last', '2'),
(206, 77, 'event_date', '20200922'),
(207, 77, '_event_date', 'field_5f102296d7d7f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(208, 77, 'page_banner_subtitle', ''),
(209, 77, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(210, 77, 'page_banner_background_image', ''),
(211, 77, '_page_banner_background_image', 'field_5f13390ee1767'),
(212, 77, 'related_programs', 'a:1:{i:0;s:2:"41";}'),
(213, 77, '_related_programs', 'field_5f11dfb711d11'),
(214, 78, '_edit_lock', '1596220000:1'),
(215, 78, '_edit_last', '1'),
(216, 78, 'page_banner_subtitle', ''),
(217, 78, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(218, 78, 'page_banner_background_image', ''),
(219, 78, '_page_banner_background_image', 'field_5f13390ee1767'),
(220, 79, 'page_banner_subtitle', ''),
(221, 79, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(222, 79, 'page_banner_background_image', ''),
(223, 79, '_page_banner_background_image', 'field_5f13390ee1767'),
(224, 80, '_edit_lock', '1596383680:1'),
(225, 80, '_edit_last', '1'),
(226, 80, 'page_banner_subtitle', ''),
(227, 80, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(228, 80, 'page_banner_background_image', ''),
(229, 80, '_page_banner_background_image', 'field_5f13390ee1767'),
(230, 81, '_edit_lock', '1596383675:1'),
(231, 81, '_edit_last', '1'),
(232, 81, 'page_banner_subtitle', ''),
(233, 81, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(234, 81, 'page_banner_background_image', ''),
(235, 81, '_page_banner_background_image', 'field_5f13390ee1767'),
(239, 81, '_wp_old_slug', 'math-lecture-1__trashed'),
(246, 80, '_wp_old_slug', 'biology-lacture-4__trashed'),
(283, 82, '_edit_lock', '1596384574:1'),
(284, 82, '_edit_last', '1'),
(285, 82, 'page_banner_subtitle', ''),
(286, 82, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(287, 82, 'page_banner_background_image', ''),
(288, 82, '_page_banner_background_image', 'field_5f13390ee1767'),
(289, 82, '_wp_trash_meta_status', 'publish'),
(290, 82, '_wp_trash_meta_time', '1596384604'),
(291, 82, '_wp_desired_post_slug', 'title-test-3'),
(292, 81, '_wp_trash_meta_status', 'publish'),
(293, 81, '_wp_trash_meta_time', '1596384606'),
(294, 81, '_wp_desired_post_slug', 'math-lecture-1'),
(295, 83, '_edit_lock', '1596394335:1'),
(296, 83, '_edit_last', '1'),
(297, 83, 'page_banner_subtitle', ''),
(298, 83, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(299, 83, 'page_banner_background_image', ''),
(300, 83, '_page_banner_background_image', 'field_5f13390ee1767'),
(304, 83, '_wp_old_slug', 'math-lecture-1__trashed-2'),
(305, 83, 'main_body_content', '<strong>dfgsdgsdgsdfgsgdsfgsdfgsg</strong>'),
(306, 83, '_main_body_content', 'field_5f21ae14a980c'),
(307, 86, '_wp_trash_meta_status', 'draft'),
(308, 86, '_wp_trash_meta_time', '1596806418'),
(309, 86, '_wp_desired_post_slug', ''),
(310, 85, '_wp_trash_meta_status', 'draft'),
(311, 85, '_wp_trash_meta_time', '1596806421'),
(312, 85, '_wp_desired_post_slug', ''),
(313, 88, '_wp_trash_meta_status', 'publish'),
(314, 88, '_wp_trash_meta_time', '1596806904'),
(315, 88, '_wp_desired_post_slug', 'hey'),
(316, 90, '_wp_trash_meta_status', 'publish'),
(317, 90, '_wp_trash_meta_time', '1596807631'),
(318, 90, '_wp_desired_post_slug', 'cats-love-maths'),
(319, 89, '_wp_trash_meta_status', 'publish'),
(320, 89, '_wp_trash_meta_time', '1596807637'),
(321, 89, '_wp_desired_post_slug', 'hey'),
(322, 87, '_wp_trash_meta_status', 'publish'),
(323, 87, '_wp_trash_meta_time', '1596807639'),
(324, 87, '_wp_desired_post_slug', 'qwerty'),
(325, 83, '_wp_trash_meta_status', 'publish'),
(326, 83, '_wp_trash_meta_time', '1596807642'),
(327, 83, '_wp_desired_post_slug', 'math-lecture-1'),
(328, 80, '_wp_trash_meta_status', 'publish'),
(329, 80, '_wp_trash_meta_time', '1596807646'),
(330, 80, '_wp_desired_post_slug', 'biology-lacture-4'),
(331, 91, '_edit_lock', '1596807667:1'),
(332, 93, '_wp_trash_meta_status', 'publish'),
(333, 93, '_wp_trash_meta_time', '1596822159'),
(334, 93, '_wp_desired_post_slug', 'cat-note-1'),
(335, 94, '_edit_lock', '1596822473:1'),
(336, 94, '_edit_last', '1'),
(337, 94, 'page_banner_subtitle', ''),
(338, 94, '_page_banner_subtitle', 'field_5f1338d4e1766'),
(339, 94, 'page_banner_background_image', ''),
(340, 94, '_page_banner_background_image', 'field_5f13390ee1767'),
(341, 95, '_wp_trash_meta_status', 'private'),
(342, 95, '_wp_trash_meta_time', '1596881688'),
(343, 95, '_wp_desired_post_slug', 'test-private-1'),
(344, 100, '_edit_lock', '1596882518:1'),
(345, 101, '_wp_trash_meta_status', 'private'),
(346, 101, '_wp_trash_meta_time', '1596883548'),
(347, 101, '_wp_desired_post_slug', 'this-is-title'),
(348, 100, '_wp_trash_meta_status', 'private'),
(349, 100, '_wp_trash_meta_time', '1596883550'),
(350, 100, '_wp_desired_post_slug', 'hack-test-html'),
(351, 99, '_wp_trash_meta_status', 'private'),
(352, 99, '_wp_trash_meta_time', '1596883552'),
(353, 99, '_wp_desired_post_slug', 'hack-test-1'),
(354, 98, '_wp_trash_meta_status', 'private'),
(355, 98, '_wp_trash_meta_time', '1596883559') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(356, 98, '_wp_desired_post_slug', 'hack-test-2'),
(357, 97, '_wp_trash_meta_status', 'private'),
(358, 97, '_wp_trash_meta_time', '1596883560'),
(359, 97, '_wp_desired_post_slug', 'hack-test'),
(360, 94, '_wp_trash_meta_status', 'private'),
(361, 94, '_wp_trash_meta_time', '1596883562'),
(362, 94, '_wp_desired_post_slug', 'cat-note-1'),
(363, 103, '_wp_trash_meta_status', 'private'),
(364, 103, '_wp_trash_meta_time', '1596885063'),
(365, 103, '_wp_desired_post_slug', 'post-4'),
(366, 102, '_wp_trash_meta_status', 'private'),
(367, 102, '_wp_trash_meta_time', '1596885066'),
(368, 102, '_wp_desired_post_slug', 'post-3'),
(369, 106, '_wp_trash_meta_status', 'private'),
(370, 106, '_wp_trash_meta_time', '1596885200'),
(371, 106, '_wp_desired_post_slug', 'post-5'),
(372, 106, '_wp_trash_meta_status', 'private'),
(373, 106, '_wp_trash_meta_time', '1596885203'),
(374, 106, '_wp_trash_meta_status', 'private'),
(375, 106, '_wp_trash_meta_time', '1596885205'),
(376, 105, '_wp_trash_meta_status', 'private'),
(377, 105, '_wp_trash_meta_time', '1596885207'),
(378, 105, '_wp_desired_post_slug', 'post-4'),
(379, 106, '_wp_trash_meta_status', 'private'),
(380, 106, '_wp_trash_meta_time', '1596885700'),
(381, 107, '_wp_trash_meta_status', 'private'),
(382, 107, '_wp_trash_meta_time', '1596885720'),
(383, 107, '_wp_desired_post_slug', '6'),
(384, 105, '_wp_trash_meta_status', 'private'),
(385, 105, '_wp_trash_meta_time', '1596885722'),
(386, 109, '_wp_trash_meta_status', 'private'),
(387, 109, '_wp_trash_meta_time', '1596885807'),
(388, 109, '_wp_desired_post_slug', '55'),
(389, 110, '_wp_trash_meta_status', 'private'),
(390, 110, '_wp_trash_meta_time', '1596886247'),
(391, 110, '_wp_desired_post_slug', '66666'),
(392, 111, '_wp_trash_meta_status', 'private'),
(393, 111, '_wp_trash_meta_time', '1596887010'),
(394, 111, '_wp_desired_post_slug', '7777'),
(395, 112, '_wp_trash_meta_status', 'private'),
(396, 112, '_wp_trash_meta_time', '1596887023'),
(397, 112, '_wp_desired_post_slug', '555555'),
(398, 114, '_edit_lock', '1596908361:1'),
(399, 114, '_edit_last', '1'),
(400, 116, '_edit_lock', '1596892116:1'),
(476, 143, 'liked_professor_id', '51'),
(481, 149, 'liked_professor_id', '47'),
(482, 150, 'liked_professor_id', '46') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------

